module.exports = (sequelize,DataTypes)=>{
    const Users = sequelize.define('user',
    {
        email:{
            type:DataTypes.STRING,
            validate:{            
                isEmail:true,
                notEmpty:true
            }
        },
        password:{
            type:DataTypes.STRING,
            validate:{
                notEmpty: true
            }
        },
        firstName:{
            type:DataTypes.STRING
        },
        lastName:{
            type:DataTypes.STRING
        },
        role:{
            type:DataTypes.STRING
        },
        tokens:{
            type:DataTypes.STRING
        },
    },
    { timestamps: false }
    
    )
    return Users
}