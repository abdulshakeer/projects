const dbconfig = require('../config/db.config.js')
const {Sequelize,DataTypes} = require('sequelize')

const sequelize = new Sequelize(
    dbconfig.DB,
    dbconfig.USER,
    dbconfig.PASSWORD,
    {
        host:dbconfig.HOST,
        dialect:dbconfig.dialect,
        pool:{
            max:dbconfig.pool.max,
            min:dbconfig.pool.min,
            acquire:dbconfig.pool.acquire,
            idle:dbconfig.pool.idle
        }
    }
)

sequelize.authenticate().then(()=>{
    console.log("Connected");
}).catch((error)=>{
    console.log(error);
})

const db = {}

db.sequelize = sequelize
db.DataTypes = DataTypes
db.users = require('../model/userModel.js')(sequelize,DataTypes)


db.sequelize.sync({alter:true}).then(()=>{
    console.log('re sync is done');
})

module.exports = db