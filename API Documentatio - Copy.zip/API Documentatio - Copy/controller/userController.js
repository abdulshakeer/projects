
require('dotenv').config()
const db = require('../model')
const User = db.users
const jwt = require('jsonwebtoken')
// Login



const loginUser = async(req,res)=>{

    // Creating Token

    const token = jwt.sign(
        {user_id:loginUser.id},
        process.env.SECRET_KEY,
        {
            expiresIn:"2h"
        }
    )
    loginUser.token = token

    const {email,password,firstName,lastName,role} = req.body
   
    const addUser = await User.create({email:email,password:password,firstName:firstName,lastName:lastName,role,tokens:loginUser.token})
    addUser._id = undefined
    addUser.password = undefined
    addUser.email = undefined
    console.log(addUser);
    res.status(200).send(addUser)
    
    // Send the cookies
    // const options = {
    //     expires:new Date(Date.now()+3*24*60*60*1000),
    //     httpOnly:true
    // }

    // res.status(200).cookie("token",token,options).json({
    //     success:true,
    //     token,
    //     addUser
    // })

}

const userassesment = async(req,res)=>{
    res.status(200).send({message:"User Details Is available"})
}

const usergraph = async(req,res)=>{
    const y = await User.findAll({})
    res.status(200).send(y)
}


const admin = async(req,res)=>{
    const z = await User.findAll({where:{role:"User"}})
    res.status(200).send(z)
}

module.exports = {
    loginUser,
    userassesment,
    usergraph,
    admin

}













