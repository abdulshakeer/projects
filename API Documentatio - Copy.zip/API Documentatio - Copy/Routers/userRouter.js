const userController = require('../controller/userController.js')
const router = require('express').Router()
const auth = require('../middleware/auth')

router.post('/login',userController.loginUser)

router.get('/userassesment',auth,userController.userassesment)

router.get('/userassesment/graph',auth,userController.loginUser)

router.get('/admin',auth,userController.admin)

module.exports = router