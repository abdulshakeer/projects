require('dotenv').config()
const express = require('express')
const app = express()
const core = require('cors')
const router = require('./Routers/userRouter.js')
const cookieParser = require('cookie-parser')


app.use(express.json())
app.use(cookieParser())
app.use(express.urlencoded({extended:true}))

// Middleware

var coreOption = {
    origin:'https:localhost:8081'
}

app.use(core(coreOption))

app.get('/',function(req,res){
    res.json({message:"Welcome To My App"})
})

// Login Users


app.use('/api',router)


// Testing API

const port = process.env.PORT || 8080
app.listen(port,()=>{
    console.log("Connected Successfully");
})